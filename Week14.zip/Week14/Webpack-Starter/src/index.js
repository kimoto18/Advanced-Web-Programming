import message from './message';
import "./css/styles.css";

console.log(message);
console.log('testing auto reload')